import React, { Component } from "react";
import { render } from "react-dom";
import App from "./App";
import "uikit/dist/css/uikit.min.css";
import "uikit/dist/js/uikit.min.js";
import "./style.css";
import "bootstrap/dist/css/bootstrap.min.css";
render(<App />, document.getElementById("root"));
